class Config:
    PATH = "existing_rules.txt"
